from django.contrib import admin
from .models import Flight
# Register your models here.
admin.site.register(Flight)  #Post is class name,after table creation,to show this in admin interface