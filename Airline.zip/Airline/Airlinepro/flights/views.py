# flights/views.py
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404, redirect
from .models import Flight
from .forms import FlightForm
from django.contrib import messages

@login_required
def main_page(request):
    flights = Flight.objects.all()
    return render(request, 'flights/main_page.html', {'flights': flights})

from django.shortcuts import render
from .models import Flight

def list_flights(request):
    flights = Flight.objects.all()
    return render(request, 'list_flights.html', {'flights': flights})


@login_required
def search_flight(request):
    if request.method == 'GET':
        flight_id = request.GET.get('flight_id')
        flight = get_object_or_404(Flight, flight_id=flight_id)
        return render(request, 'flights/detail.html', {'flight': flight})

@login_required
def add_flight(request):
    if request.method == 'POST':
        form = FlightForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Flight added successfully!')
            return redirect('main_page')
    else:
        form = FlightForm()
    return render(request, 'flights/form.html', {'form': form})


@login_required
def edit_flight(request, flight_id):
    flight = get_object_or_404(Flight, flight_id=flight_id)
    if request.method == 'POST':
        form = FlightForm(request.POST, instance=flight)
        if form.is_valid():
            form.save()
            messages.success(request, 'Flight updated successfully!')
            return redirect('main_page')  # Redirect to main page
    else:
        form = FlightForm(instance=flight)
    return render(request, 'flights/form.html', {'form': form})



@login_required
def delete_flight(request, flight_id):
    flight = get_object_or_404(Flight, flight_id=flight_id)
    if request.method == 'POST':
        flight.delete()
        messages.success(request, 'Flight deleted successfully!')
        return redirect('main_page')  # Redirect to main page
    return render(request, 'flights/confirm_delete.html', {'flight': flight})

