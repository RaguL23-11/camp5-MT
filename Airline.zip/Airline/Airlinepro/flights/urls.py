
from django.urls import path
from .views import list_flights, search_flight, add_flight, edit_flight, delete_flight, main_page

urlpatterns = [
    path('', main_page, name='main_page'),
    path('list/', list_flights, name='list_flights'),
    path('search/', search_flight, name='search_flight'),
    path('add/', add_flight, name='add_flight'),  # Points to add flight view
    path('edit/<str:flight_id>/', edit_flight, name='edit_flight'),  # Points to edit flight view
    path('delete/<str:flight_id>/', delete_flight, name='delete_flight'),
    path('flights/', list_flights, name='list_flights'),
    path('flights/add/', add_flight, name='add_flight'),
    path('flights/edit/<int:flight_id>/', edit_flight, name='edit_flight'),
]



