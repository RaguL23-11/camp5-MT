# Airlinepro/urls.py
from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from django.views.generic import RedirectView  # Import RedirectView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('flights/', include('flights.urls')),  # Corrected to point to your flights app URLs

    # Authentication URLs
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),

    # Redirect root URL to login
    path('', RedirectView.as_view(url='/login/')),  # Redirect root to login
]
